
public class Edades {

}
